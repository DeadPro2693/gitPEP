psexec.exe -accepteula
pssuspend.exe -accepteula
function susbend-veyon {
    .\pssuspend.exe veyon-server
    .\pssuspend.exe veyon-worker
    .\pssuspend.exe veyon-service
    psexec.exe -accepteula
pssuspend.exe -accepteula
}
function sus-v-2{
    susbend-veyon
    susbend-veyon
}

if (-Not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    if ([int](Get-CimInstance -Class Win32_OperatingSystem | Select-Object -ExpandProperty BuildNumber) -ge 6000) {
        Start-Process PowerShell -Verb RunAs -ArgumentList "-NoProfile -ExecutionPolicy Bypass -Command `"cd '$pwd'; & '$PSCommandPath';`"";
        Exit;
    }
}
cd 'C:\ProgramData\Project Power\'
.\nircmd.exe setsysvolume 0
.\nircmd.exe mutesysvolume 1
psexec.exe -accepteula
pssuspend.exe -accepteula
sus-v-2
REG ADD HKEY_CURRENT_USER\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\NewStartPanel /v "{645FF040-5081-101B-9F08-00AA002F954E}" /t REG_DWORD /d 1 /f
REG ADD HKEY_CURRENT_USER\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\ClassicStartMenu /v "{645FF040-5081-101B-9F08-00AA002F954E}" /t REG_DWORD /d 1 /f
REG ADD HKEY_CURRENT_USER\SOFTWARE\Microsoft\Clipboard /v EnableClipboardHistory /t REG_DWORD /d 1 /f

del "C:\Users\Public\Desktop\Abmelden.lnk"
del "C:\Users\Public\Desktop\BSH - Itslearning.lnk"
del "C:\Users\Public\Desktop\BSH Schulportal.url"
del "C:\Users\Public\Desktop\Firefox.lnk"
del "C:\Users\Public\Desktop\Microsoft Edge.lnk"
del "C:\Users\Public\Desktop\WorkSpace.lnk"
REG ADD HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System /v EnableLUA /t REG_DWORD /d 0 /f
.\copy.bat
stop-process -name explorer
Start-Sleep -Seconds 5
..\data\FF.deskthemepack
Start-Sleep -Seconds 5
stop-process -name SystemSettings
resmon
C:\Windows\System32\UserAccountControlSettings.exe

start C:\ProgramData\data\installs\TaskbarX_portable\TaskbarX.exe
start C:\ProgramData\data\installs\TaskbarX_portable\TaskbarX Configurator.exe
